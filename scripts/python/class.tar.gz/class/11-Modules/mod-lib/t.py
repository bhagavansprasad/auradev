#import fact
from fact import factorial

#print fact.factorial(5)
print factorial(5)
