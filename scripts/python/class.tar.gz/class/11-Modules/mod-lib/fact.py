def factorial(n):
    temp = 1
    for i in range(1, n+1):
        temp *= i
    
    return temp
