import sys
#import fact

#print fact.factorial(5)
print ("Hello")
