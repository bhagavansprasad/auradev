import sys
sys.path.append('/home/bhagavan/training/scripts/python/class/11-Modules/mod-lib')
import amath

n = 5
t = amath.is_prime(5)
print t 
