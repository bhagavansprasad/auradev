import pygit2
import sys

#To print module path
print "file",     pygit2.__file__
print "name ",    pygit2.__name__
print "package ", pygit2.__package__
print "path ",    pygit2.__path__
print "version ", pygit2.__version__
print "build   ", pygit2._build 
print "other ",   pygit2._libgit2

