import os

retval =  os.system("ls")
print hex(retval)
