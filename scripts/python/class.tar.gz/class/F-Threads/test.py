import sys
import os
import time

print "child ", os.getpid()
time.sleep(20)
sys.exit(0)
