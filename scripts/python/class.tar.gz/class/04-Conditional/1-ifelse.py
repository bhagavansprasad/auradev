a=40
b=40
c=40

if (a > b):
        if (a > c):
                print ("A is big")
        else:
                print ("C is big")
elif( b > c):
        print ("B is big")
else:
        print ("C is big")

print 10%2 == 1
print 10%2 == 0


if (1):
    print "I am in if block"

if (10):
    print "I am in if block"

if (-1):
    print "I am in if block"

if (-10):
    print "I am in if block"

if (0):
    print "I am in if block"
else:
    print "I am in else block"

if (True):
    print "I am in if block"
else:
    print "I am in else block"

if (False):
    print "I am in if block"
else:
    print "I am in else block"
a = 10 > 5
b = 10 < 5

print "a ", a
print "b ", b


