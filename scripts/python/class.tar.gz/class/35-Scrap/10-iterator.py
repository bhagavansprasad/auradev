mylist = [10, 20, 30, 40, 50, 60, 70]

for i in range(0, 5):
    print mylist[i]

print ""
for element in mylist:
    print element
