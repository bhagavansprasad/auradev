strdate = "2017-08-11T03:00:34.770561686Z"
list1 = strdate.split('T')
print list1[0]
