ls1 = ["bhagavan", 1020, 2233, "9902096750", 42, "Male"]
ls2 = ["prasad", 1021, 2234, "99020 96750", 40, "Male"]

if (ls1[3] == ls2[3]):
    print "Duplicate"
else:
    print "Not a Duplicate"
