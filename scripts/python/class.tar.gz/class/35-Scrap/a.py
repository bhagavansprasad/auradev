
print find_factorial_value(5)
