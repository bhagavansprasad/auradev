list_of_cities = ["bagalore", "delhi", "mumbai", "chennai"]

while True:
    for cityname in list_of_cities:
	print "Citiy name is :", " ", cityname

#comment


