import os

retval =  os.system("ls")
print "retval :", hex(retval)
