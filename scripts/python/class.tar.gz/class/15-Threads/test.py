import os
import sys

print "Mypid :", os.getpid()

sys.exit()
''' 
if (open == -1)
	sys.exit(0)

if (write() < 0)
	sys.exit(1)
''' 
