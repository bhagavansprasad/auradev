s1 = '''This string contains """ so use triple-single-quotes.'''
s2 = """This string contains ''' so use triple-double-quotes."""
s3 = """This string ' con "tains ''' so use triple-double-quotes."""

print s1
print s2
print s3
