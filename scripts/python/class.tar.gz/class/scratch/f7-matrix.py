a = [
        [1, 2],
        [3, 4]
    ]

i = j = 0

while (i < 2):
    j = 0
    while (j < 2):
        print " ", a[i][j], 
        j += 1
    print ""
    i += 1
