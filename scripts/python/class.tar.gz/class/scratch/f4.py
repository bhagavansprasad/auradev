a = [1,2,3,4,5]
print a
print a[1:]
print a[-1:]
print a[:-1]
