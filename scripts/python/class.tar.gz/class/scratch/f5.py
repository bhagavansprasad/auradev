mylist = [1,7,8,9,5]


x = t = len(mylist)
t = t  - 2
#while (t > t-4):
while (t > x-5):
    print mylist[t]
    t = t - 1

