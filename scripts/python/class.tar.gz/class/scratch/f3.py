a = 10

print a

print a+10

print a
