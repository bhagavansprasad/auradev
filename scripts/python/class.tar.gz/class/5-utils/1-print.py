print '%s %s %s' % ('python','aslkjdflkajsdklfjasldfj','fun')
print '%-30s %30s %s'% ('python','aslkjdflkajsdklfjasldfj','fun')
print '%-30s %30s %s'% ('pythonxxxxxx','aslkjdfl','fun')
print '%10s %30s %s'% ('howare you','is','fun')
print '%10s %30s %s'% ('where','is','fun')
print '%10d %30d %s'% (10,20, 'fun')

