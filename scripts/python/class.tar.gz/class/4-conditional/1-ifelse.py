a=40
b=40
c=40

if (a > b):
        if (a > c):
                print ("A is big")
        else:
                print ("C is big")
elif( b > c):
        print ("B is big")
else:
        print ("C is big")
