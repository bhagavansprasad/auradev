def foo(bar):
    return bar + 1


print(foo(2) == 3)
