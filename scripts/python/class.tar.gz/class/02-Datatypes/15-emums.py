from enum import Enum

class Color(Enum):
    RED = 0xFA1B00
    GREEN = 2
    BLUE = 3

print Color.RED


