myobject = [
    {
        "Id": "0b8dccc201b0be71d47ede92cb9e1801069f9e0b39505a7c6a32cabf7ada633a",
        "Created": "2016-12-29T10:30:07.119045211Z",
        "Path": "nginx"
    }
    ]

print myobject
print myobject[0]
print myobject[0]["Id"]
print myobject[0]["Id"][:13]
