a = 15

print a/2
print a/3
print a//2
