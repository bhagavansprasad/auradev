print 'python','is a scritpting language', 'fun'
print '%s%s%s' % ('python','is a scritpting language', 'fun')

print 'python','is a scritpting language', 'fun'
print 'Perl','is a another language', 'fun'
print 'C','is a programm language', 'fun'
print 'C++','is a opps language', 'fun'


print "%10s %30s %s" % ('python','is a scritpting language', 'fun')
print '%10s %30s %s' % ('Perl','is a another language', 'fun')
print '%10s %30s %s' % ('C','is a programm language', 'fun')
print '%10s %30s %s' % ('C++','is a opps language', 'fun')


print '%-30s %30s %s'% ('python','is a scritpting language','fun')
print '%-30s %30s %s'% ('pythonxxxxxx','scripting','fun')
print '%10s %30s %s'% ('howare you','is','fun')
print '%10s %30s %s'% ('where','is','fun')
print '%10d %30d %s'% (10,20, 'fun')

print "hello world, I'am Bhagavan"
print 'hello world, I\'m Bhagavan'
print "hello world, I'm Bhagavan"
print 'hello world, I"m Bhagavan'
print """hello' world, I'm Bhaga"van"""

exit(1)

