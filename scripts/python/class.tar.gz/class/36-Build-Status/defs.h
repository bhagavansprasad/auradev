int get_factorial_value(int n);
