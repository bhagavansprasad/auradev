test_string = ["amath.c:12:9: warning: i mazed in thisitialized\]",
                "alsdjflajsd lasd   warning kasdlfjalsjdflj",
                "alsdjflajsd lasd kasdlfjalsjdflj",
                "alsdjflajsd lasd warn kasdlfjalsjdflj",
                ]

substr = "warning"
print test_string.find(substr)
open("1log.txt")

