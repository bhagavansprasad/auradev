import sys
sys.path.append('/home/bhagavan/students/bhagavan/scripts/python/class/G-Modules/modules/')
from fact import *

n = 5
print factorial(n)
print ""
