import fibmod

fibmod.print_fib_series(20)

print ""

print fibmod.get_fib_series(20)
