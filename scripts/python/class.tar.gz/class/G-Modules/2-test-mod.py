#from fibmod import print_fib_series
#from fibmod import print_fib_series, get_fib_series
#from fibmod import *

print_fib_series(20)

print ""

print get_fib_series(20)
