n = 25
for i in range(2, n):
    if (n%i == 0):
        print "NP"
else:
    print "P"
