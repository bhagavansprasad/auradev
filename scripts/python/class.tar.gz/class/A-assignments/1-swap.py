a, b, c = 10, 20, 0

print a, ":", b

c = a
a = b
b = c

print a, ":", b

