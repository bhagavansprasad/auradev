if "Br" in "Brother":
	print "contains brother"

email_address = "testuser"
if "@" not in email_address:
    print "Invalid email ID"
    email_address += "@auranetworks.in"
else:
    print "Valid email ID"

print email_address

for i in range(1,10):
    print i

