print "Hello how are"

a = 10
b = 20
print "a :", a
print  a

print "b :", b
c = a + b
print "sum  :", c
print "prod :", a * b


a = 'abc'
b = 'xyz'

print "5*a :", 5*a 
print "a+b :", a+b

a = 0
a = a + 10
a += 10
print "a :", a

print "a pow 2 :", a ** 2

a = 15
print "a / 2 :",  a / 2
print "a // 2 :", a // 2
print "a % 2 :", a % 2

exit(1)
a = 15.5
print a / 2
print a // 2

