def to_upper(tstr):
    return tstr.upper()
