def myfun():
    yield 1
    yield 2
    yield 3

for item in myfun():
    print item

'''
def createGenerator():
    mylist = range(3)
    for i in mylist:
        yield i*i

mygenerator = createGenerator()
for i in mygenerator:
     print(i)
'''
