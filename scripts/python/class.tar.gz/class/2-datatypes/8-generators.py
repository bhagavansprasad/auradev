mygenr = (x*x for x in range(5))

for i in mygenr:
   print(i)
