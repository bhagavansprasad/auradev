x = 1
while True:
    #print "To infinity and beyond! We're getting close, on %d now!" % (x)
    x += 1
    if (x == 10000000):
        print "To infinity and beyond! We're getting close, on %d now!" % (x)
        break;

i = 0
while (i <= 10):
	print i
	i+=2
print i

