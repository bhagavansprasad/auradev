n = 5
i = 0
for i in range(5, n):
    print i
print i
