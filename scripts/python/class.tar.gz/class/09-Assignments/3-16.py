temp = 65

print temp

print "%d %c" % (temp, temp)

for i in range(0, 26):
    print "%c" % (temp+i),
