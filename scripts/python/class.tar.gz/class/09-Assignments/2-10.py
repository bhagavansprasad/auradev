i = 4
n = 10

for i in range (1, n+1):
    print i
    if (i % 5 == 0):
        i += 4
print i
