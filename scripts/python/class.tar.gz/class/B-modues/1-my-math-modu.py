def is_prime(int n):
    i = 2
    while (i < n):
        if (n % i == 0):
            break
    if (i == n):
        return 0
    else
        return 1

def is_even(int n):
    return (!n%2)

def is_odd(int n):
    return (n%2)

