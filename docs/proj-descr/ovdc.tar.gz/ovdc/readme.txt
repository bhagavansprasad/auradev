ovdc.txt - "Readme file for ovdc before doing project
		It includes all assignments and topics to read

ovdc.ppt - Explains the need and design of the OVDC
